                   === fantacampionatoonline ===
Contributors: Marco, Diego, Antonio d
Donate link: www.fantacampionatoonline.com
Tags: calcio fantacalcio fantacampionato football campionato torneo calciatori
Requires at least: 3.3
Tested up to: 3.4.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Questo plugin simula il gioco del fantacalcio sul vostro portale wordpress. Infatti con un meccanismo automatizzato vi da la possibilit� di creare un campionato e gestire tutti i partecipanti, aggiornando voti e classifica giornate x giornata.

== Description ==

Il plugin gestisce tutti gli aspetti dell fantacalcio che interessano tutti gli amanti di questo gioco.
IL PROGRAMMA OFFRE:
  
- Creazione illimitata di squadre
- Calcolo automatico dei voti settimanali
- Calcolo automatico della classifica settimanale e totale
- Gestione da parte degli utenti della formazione settimanale
- Gestione dall'utente dell'acquisto dei giocatori nelle finestre di mercato
- Gestine dall'amministratore di tutti gli utenti e dei soldi a loro disposizione
- Controllo dei voti settimali
- Modulu di segnalazione per eventuali difficolta di gestione
- Assoluta assistenza da parte dei programmatori del programma

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Place, add the tag [fantacampionato] in the desired page.

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==



== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==

