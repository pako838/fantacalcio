
<!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
    <title></title>
  </head>
  <body>
      <p style="text-align: center; color: fuchsia; font-size: 40px" >Seleziona opzione :</p>
    <table border="0" style="width: 100%;">
      <tbody>
        <tr>
          <td align="center">
               <a href="./continua_torneo.php"><img width="227" height="227" src="./continua_torneo.png" alt="Contina torneo" /></a>
          <br />
          </td>
          <td align="center">
              <a href="./form_iscrizione_squadra.php"><img width="227" height="227" src="./nuovo_torneo.png" alt="Nuovo torneo" /></a>
              
              <br />
          </td>
        </tr>
      </tbody>
    </table>
    <p><br />
    </p>
  </body>
</html>

