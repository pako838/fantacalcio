<!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
    <title></title>
  </head>
  <body>
      <p align="center"><a href="./selezione.php"><img src="./logo_fantacampionatoonline.png"

        alt="logo_fantacampionatoonline.com" /></a></p>
    <p align="center" style=" font-size: 25px;"><font color="#ff99ff">Benvenuto nel programma
        fantacampiontoonline.</font></p>
      <p align="center" style=" font-size: 25px;"><font color="#ff99ff">Con pochi e semplici passi potrai
        anche tu configurare il tuo fantacampionato!!!</font><br />
    </p>
  </body>
</html>
